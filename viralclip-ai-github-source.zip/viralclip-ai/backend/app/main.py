from __future__ import annotations
import os, re, uuid, shutil, subprocess
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()
BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "data"
UPLOADS = DATA / "uploads"
MEDIA = DATA / "media"
for p in (UPLOADS, MEDIA): p.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="ViralClip AI API", version="0.1.0")
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["*"], allow_headers=["*"])
app.mount("/media", StaticFiles(directory=MEDIA), name="media")

JOBS: dict[str, dict] = {}

def run(cmd: list[str], timeout: int = 1800) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=True)
    except FileNotFoundError:
        raise HTTPException(500, "FFmpeg is not installed or not available on PATH.")
    except subprocess.CalledProcessError as e:
        detail = (e.stderr or e.stdout or "Media processing failed")[-1800:]
        raise HTTPException(400, f"Media processing failed: {detail}")
    except subprocess.TimeoutExpired:
        raise HTTPException(408, "Processing timed out. Try a shorter video.")

def duration_of(path: Path) -> float:
    p = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    try: return float(p.stdout.strip())
    except ValueError: raise HTTPException(400, "Could not read video duration.")

def transcribe(path: Path) -> tuple[list[dict], bool]:
    if os.getenv("ENABLE_WHISPER", "false").lower() != "true":
        return [], False
    try:
        import whisper
        model = whisper.load_model(os.getenv("WHISPER_MODEL", "tiny"))
        result = model.transcribe(str(path), verbose=False)
        return [{"start": float(s["start"]), "end": float(s["end"]), "text": str(s["text"]).strip()} for s in result.get("segments", [])], True
    except Exception:
        return [], False

def suggest_clips(total: float, length: int, segments: list[dict]) -> list[dict]:
    length = max(15, min(30, int(length)))
    if total < length:
        length = max(1, int(total))
    candidates = []
    if segments:
        # Score segments with conversational / reaction hooks. This is a lightweight heuristic,
        # not a claim that a moment will go viral.
        hooks = re.compile(r"\b(why|how|secret|never|best|worst|imagine|wait|look|because|actually|wow|crazy|mistake|important|finally|but|however|first|only|win|fail|surprise)\b", re.I)
        step = max(5, length // 2)
        starts = set()
        for seg in segments:
            center = (seg["start"] + seg["end"]) / 2
            starts.add(max(0, min(max(0, total - length), center - length * .45)))
        # Add a coarse set of windows so candidates aren't only around hook words.
        starts.update(float(x) for x in range(0, max(1, int(total - length) + 1), step))
        for start in starts:
            end = min(total, start + length)
            text = " ".join(s["text"] for s in segments if s["end"] > start and s["start"] < end).strip()
            if not text: continue
            words = len(text.split())
            hook_count = len(hooks.findall(text))
            # Reward useful speech density and hook terms; gently penalize extremely short transcript windows.
            score = min(95, 45 + hook_count * 8 + min(words, 70) * 0.25)
            if words < 8: score -= 15
            candidates.append({"start": round(start, 2), "end": round(end, 2), "duration": round(end-start, 2),
                               "score": round(max(20, score), 1), "transcript": text[:600]})
    if not candidates:
        max_start = max(0, total - length)
        points = sorted(set([0.0, max_start * .25, max_start * .5, max_start * .75, max_start]))
        candidates = [{"start": round(s, 2), "end": round(min(total, s+length), 2),
                       "duration": round(min(total, s+length)-s, 2), "score": None,
                       "transcript": ""} for s in points]
    # Deduplicate near-identical start times and return up to 8 candidates.
    candidates.sort(key=lambda c: ((c["score"] or 0), -c["start"]), reverse=True)
    out = []
    for c in candidates:
        if all(abs(c["start"] - x["start"]) >= max(4, length * .45) for x in out):
            out.append(c)
        if len(out) == 8: break
    out.sort(key=lambda c: c["start"])
    for i, c in enumerate(out, 1): c["id"] = f"clip-{i}"
    return out

def analyze_file(path: Path, source_name: str, length: int) -> dict:
    total = duration_of(path)
    if total < 1: raise HTTPException(400, "This file does not appear to contain a usable video.")
    segments, used_whisper = transcribe(path)
    job_id = uuid.uuid4().hex[:12]
    # Copy into a stable managed location.
    stable = UPLOADS / f"{job_id}{path.suffix.lower() or '.mp4'}"
    if path.resolve() != stable.resolve(): shutil.copy2(path, stable)
    clips = suggest_clips(total, length, segments)
    JOBS[job_id] = {"path": str(stable), "duration": total, "clips": clips, "source_name": source_name, "segments": segments}
    return {"job_id": job_id, "source_name": source_name, "video_duration": round(total, 2),
            "transcription_available": used_whisper, "analysis_mode": "whisper_heuristic" if used_whisper else "fallback_windows",
            "message": "Candidate moments ranked from transcript heuristics." if used_whisper else "Whisper is disabled or unavailable; showing heuristic time windows, not AI-ranked moments.",
            "clips": clips}

class AnalyzeRequest(BaseModel):
    url: str = Field(min_length=8, max_length=2000)
    duration: int = Field(default=20, ge=15, le=30)

class ExportRequest(BaseModel):
    job_id: str
    start: float = Field(ge=0)
    duration: int = Field(default=20, ge=15, le=30)
    vertical: bool = True
    captions: bool = True
    caption_text: Optional[str] = None

@app.get("/api/health")
def health():
    return {"ok": True, "whisper_enabled": os.getenv("ENABLE_WHISPER", "false").lower() == "true"}

@app.post("/api/analyze")
def analyze(req: AnalyzeRequest):
    # URL fetching is deliberately limited to ordinary yt-dlp-supported sources; no DRM,
    # authentication-wall, or paywall bypass is implemented.
    if not re.match(r"^https?://", req.url.strip(), re.I):
        raise HTTPException(400, "Enter a valid http or https URL.")
    try:
        import yt_dlp
    except ImportError:
        raise HTTPException(500, "yt-dlp is missing. Install backend/requirements.txt or upload a local video.")
    temp_id = uuid.uuid4().hex
    outtmpl = str(UPLOADS / f"{temp_id}.%(ext)s")
    opts = {"format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
            "outtmpl": outtmpl, "merge_output_format": "mp4", "noplaylist": True,
            "quiet": True, "no_warnings": True, "socket_timeout": 25,
            "max_filesize": int(os.getenv("MAX_UPLOAD_MB", "800")) * 1024 * 1024}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(req.url.strip(), download=True)
            downloaded = Path(ydl.prepare_filename(info))
            if not downloaded.exists():
                mp4 = downloaded.with_suffix(".mp4")
                downloaded = mp4 if mp4.exists() else downloaded
            if not downloaded.exists():
                matches = list(UPLOADS.glob(f"{temp_id}.*"))
                if not matches: raise HTTPException(400, "The source did not produce a downloadable video file.")
                downloaded = matches[0]
            return analyze_file(downloaded, info.get("title") or "Imported video", req.duration)
    except HTTPException:
        raise
    except Exception as e:
        for p in UPLOADS.glob(f"{temp_id}.*"):
            try: p.unlink()
            except OSError: pass
        raise HTTPException(400, f"Could not import this URL. Check access rights, source support, and the site's terms. Details: {str(e)[:400]}")

@app.post("/api/upload")
async def upload(file: UploadFile = File(...), duration: int = 20):
    if duration < 15 or duration > 30: raise HTTPException(400, "Duration must be between 15 and 30 seconds.")
    suffix = Path(file.filename or "video.mp4").suffix.lower()
    if suffix not in {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi"}: suffix = ".mp4"
    temp = UPLOADS / f"upload-{uuid.uuid4().hex}{suffix}"
    limit = int(os.getenv("MAX_UPLOAD_MB", "800")) * 1024 * 1024
    size = 0
    try:
        with temp.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > limit:
                    raise HTTPException(413, f"File exceeds the {limit // (1024*1024)} MB upload limit.")
                out.write(chunk)
        return analyze_file(temp, file.filename or temp.name, duration)
    finally:
        await file.close()

@app.post("/api/export")
def export_clip(req: ExportRequest):
    job = JOBS.get(req.job_id)
    if not job: raise HTTPException(404, "Analysis session not found. Analyze or upload the video again.")
    src = Path(job["path"])
    if not src.exists(): raise HTTPException(404, "Source file has expired or was removed.")
    if req.start >= job["duration"]: raise HTTPException(400, "Clip start is beyond the end of the video.")
    duration = min(req.duration, max(1, job["duration"] - req.start))
    out_name = f"viralclip-{uuid.uuid4().hex[:10]}.mp4"
    out = MEDIA / out_name
    filters = []
    if req.vertical:
        filters.append("scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920")
    else:
        filters.append("scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2")
    caption_file = None
    warning = None
    if req.captions:
        # Prefer transcript-timed subtitles when Whisper is available. Otherwise,
        # burn the user-entered caption as a simple fallback overlay.
        segments = job.get("segments", [])
        srt_lines = []
        def stamp(seconds):
            ms = max(0, int(round(seconds * 1000)))
            hours, rem = divmod(ms, 3600000)
            minutes, rem = divmod(rem, 60000)
            secs, millis = divmod(rem, 1000)
            return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"
        for seg in segments:
            left = max(float(req.start), float(seg.get("start", 0)))
            right = min(float(req.start) + duration, float(seg.get("end", 0)))
            txt = str(seg.get("text", "")).strip().replace("-->", "→")
            if right <= left or not txt:
                continue
            srt_lines.extend([str(len(srt_lines)//4 + 1), f"{stamp(left-req.start)} --> {stamp(right-req.start)}", txt, ""])
        if srt_lines:
            caption_file = MEDIA / f"{uuid.uuid4().hex}.srt"
            caption_file.write_text("\n".join(srt_lines), encoding="utf-8")
        elif req.caption_text and req.caption_text.strip():
            caption_file = MEDIA / f"{uuid.uuid4().hex}.srt"
            safe_text = req.caption_text.strip().replace("-->", "→")
            caption_file.write_text(f"1\n00:00:00,000 --> {stamp(duration)}\n{safe_text}\n", encoding="utf-8")
            warning = "No speech transcript was available; the entered caption is burned in for the clip duration."
        else:
            warning = "No transcript or caption text was available; exported without captions."
        if caption_file:
            escaped_path = caption_file.as_posix().replace(":", r"\:")
            filters.append(f"subtitles='{escaped_path}'")
    cmd = ["ffmpeg", "-y", "-ss", str(req.start), "-i", str(src), "-t", str(duration),
           "-vf", ",".join(filters), "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
           "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(out)]
    try:
        run(cmd, timeout=1800)
    finally:
        if caption_file and caption_file.exists():
            try: caption_file.unlink()
            except OSError: pass
    return {"filename": out_name, "download_url": f"/media/{out_name}", "duration": round(duration, 2),
            "vertical": req.vertical, "warning": warning}
