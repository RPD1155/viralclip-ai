import React, { useState, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { Scissors, Sparkles, Link2, Upload, Play, Download, Captions, Smartphone, Clock3, Film, CheckCircle2, AlertCircle, LoaderCircle, WandSparkles, FileVideo2, ChevronRight, X, ExternalLink } from 'lucide-react';
import './styles.css';

const API_BASE = import.meta.env.VITE_API_BASE_URL || '';
const fmt = (n) => { const s=Math.floor(n||0); return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`; };
function App() {
  const [url,setUrl]=useState('');
  const [duration,setDuration]=useState(20);
  const [vertical,setVertical]=useState(true);
  const [captions,setCaptions]=useState(true);
  const [captionText,setCaptionText]=useState('The moment everyone missed');
  const [file,setFile]=useState(null);
  const [result,setResult]=useState(null);
  const [selected,setSelected]=useState(0);
  const [busy,setBusy]=useState(false);
  const [exporting,setExporting]=useState(false);
  const [error,setError]=useState('');
  const [exported,setExported]=useState(null);
  const fileRef=useRef(null);
  const active=result?.clips?.[selected];

  async function parseResponse(res) {
    const data=await res.json().catch(()=>({detail:'Unexpected server response'}));
    if(!res.ok) throw new Error(data.detail || 'Request failed');
    return data;
  }
  async function analyze() {
    setError(''); setResult(null); setExported(null);
    if(!file && !url.trim()) { setError('Paste a video URL or upload a video file first.'); return; }
    setBusy(true);
    try {
      let res;
      if(file) {
        const form=new FormData(); form.append('file',file); form.append('duration',String(duration));
        res=await fetch(`${API_BASE}/api/upload`,{method:'POST',body:form});
      } else {
        res=await fetch(`${API_BASE}/api/analyze`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:url.trim(),duration})});
      }
      const data=await parseResponse(res);
      setResult(data); setSelected(0);
    } catch(e) { setError(e.message || 'Could not analyze this video. Is the backend running?'); }
    finally { setBusy(false); }
  }
  async function exportClip() {
    if(!result || !active) return;
    setError(''); setExporting(true); setExported(null);
    try {
      const res=await fetch(`${API_BASE}/api/export`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_id:result.job_id,start:active.start,duration:Math.max(15,Math.min(30,Math.round(active.duration||duration))),vertical,captions,caption_text:captions?captionText:''})});
      const data=await parseResponse(res);
      setExported({...data,url:`${API_BASE}${data.download_url}`});
    } catch(e) { setError(e.message || 'Export failed. Check FFmpeg and backend logs.'); }
    finally { setExporting(false); }
  }
  function chooseFile(e) { const f=e.target.files?.[0]; if(f){setFile(f);setUrl('');setResult(null);setExported(null);} }
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><Scissors size={21}/></div><span>ViralClip<span className="brand-ai"> AI</span></span><span className="beta">BETA</span></div>
      <div className="side-label">WORKSPACE</div>
      <div className="side-item active"><Film size={17}/> Clip studio</div>
      <div className="side-item muted"><Captions size={17}/> Captions <span className="soon">TOOLS</span></div>
      <div className="side-item muted"><Smartphone size={17}/> Export formats</div>
      <div className="side-bottom"><div className="status-dot"></div><div><b>Open-source edition</b><small>Runs on your own backend</small></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="crumb">Workspace <ChevronRight size={14}/> <b>Clip studio</b></div><div className="top-right"><span className="secure"><span className="status-dot"/> Local processing</span><div className="avatar">VC</div></div></header>
      <div className="content">
        <section className="hero">
          <div className="eyebrow"><Sparkles size={14}/> AI-ASSISTED VIDEO CLIPPING</div>
          <h1>Long video in.<br/><span>Short-form gold out.</span></h1>
          <p>Find promising moments, shape them into vertical clips, and export ready-to-share MP4s.</p>
        </section>
        <section className="source-card">
          <div className="section-heading"><div className="heading-icon"><Link2 size={18}/></div><div><h2>Choose your source</h2><p>Use a video you own or have permission to edit.</p></div><div className="step">01 <span>/ 03</span></div></div>
          <div className="url-input-wrap"><Link2 size={18}/><input value={url} onChange={e=>{setUrl(e.target.value);if(e.target.value)setFile(null)}} placeholder="Paste a YouTube or supported video URL..." aria-label="Video URL"/><button className="upload-btn" onClick={()=>fileRef.current?.click()}><Upload size={16}/> Upload</button><input ref={fileRef} type="file" accept="video/*" hidden onChange={chooseFile}/></div>
          {file && <div className="file-pill"><FileVideo2 size={15}/><span>{file.name}</span><button onClick={()=>setFile(null)} aria-label="Remove file"><X size={14}/></button></div>}
          <div className="options-row"><div className="duration-setting"><span>CLIP LENGTH</span><div className="segmented">{[15,20,25,30].map(n=><button key={n} className={duration===n?'chosen':''} onClick={()=>setDuration(n)}>{n}s</button>)}</div></div><div className="privacy-note"><AlertCircle size={14}/> Processing requires a running backend</div></div>
          <button className="primary-btn" onClick={analyze} disabled={busy}>{busy?<><LoaderCircle className="spin" size={18}/> Finding moments...</>:<><WandSparkles size={18}/> Find best moments <span className="btn-arrow">↗</span></>}</button>
          {error && <div className="error-box"><AlertCircle size={17}/><span>{error}</span></div>}
        </section>
        {busy && <div className="processing"><div className="processing-icon"><LoaderCircle className="spin" size={22}/></div><div><b>Analyzing your video</b><p>Reading video duration and looking for candidate moments. Longer videos may take a while.</p></div></div>}
        {result && <section className="results-section">
          <div className="results-title"><div><div className="eyebrow"><Sparkles size={14}/> ANALYSIS RESULTS</div><h2>Your clip candidates</h2><p>{result.source_name} · {fmt(result.video_duration)} total runtime</p></div><span className="count-badge">{result.clips.length} MOMENTS</span></div>
          <div className="notice"><AlertCircle size={16}/><span>{result.message} These are candidate moments, not a guarantee of virality.</span></div>
          <div className="editor-grid">
            <div className="candidate-list"><div className="list-head">CANDIDATE MOMENTS <span>{result.clips.length}</span></div>
              {result.clips.map((clip,i)=><button key={clip.id} className={`clip-card ${selected===i?'selected':''}`} onClick={()=>{setSelected(i);setExported(null)}}><div className="clip-thumb"><Play size={18} fill="currentColor"/><span>{fmt(clip.start)}</span></div><div className="clip-info"><b>Moment {String(i+1).padStart(2,'0')}</b><small>{fmt(clip.start)} – {fmt(clip.end)} · {Math.round(clip.duration)} sec</small><div className="clip-tags">{clip.score!==null&&clip.score!==undefined?<span className="score"><Sparkles size={11}/> {Math.round(clip.score)} score</span>:<span className="heuristic">Suggested window</span>}</div></div><ChevronRight size={16} className="clip-chevron"/></button>)}
            </div>
            <div className="preview-panel">
              <div className="preview-top"><div><b>Clip preview</b><small>{active?`${fmt(active.start)} start point`:''}</small></div><span className="live-badge"><span className="status-dot"/> READY TO EDIT</span></div>
              <div className={`preview-frame ${vertical?'vertical':'landscape'}`}>
                {file && <video key={`${selected}-${active?.start}`} controls src={URL.createObjectURL(file)} onLoadedMetadata={e=>{try{e.target.currentTime=active?.start||0}catch{}}} />}
                {!file && <div className="preview-placeholder"><div className="play-orb"><Play size={23} fill="currentColor"/></div><b>Clip selected</b><span>{active?`${fmt(active.start)} → ${fmt(active.end)}`:''}</span><small>Export to render the selected segment</small></div>}
                {captions && captionText && <div className="caption-overlay">{captionText}</div>}
              </div>
              <div className="preview-meta"><span><Clock3 size={14}/> {active?Math.round(active.duration):duration}s duration</span><span><Smartphone size={14}/> {vertical?'9:16 vertical':'16:9 landscape'}</span></div>
              <div className="edit-controls"><label className="control-label">EXPORT FORMAT</label><div className="format-options"><button className={vertical?'format-card active':''} onClick={()=>setVertical(true)}><Smartphone size={18}/><span><b>Vertical</b><small>9:16 · Shorts / Reels</small></span>{vertical&&<CheckCircle2 size={16}/>}</button><button className={!vertical?'format-card active':''} onClick={()=>setVertical(false)}><Film size={18}/><span><b>Landscape</b><small>16:9 · YouTube</small></span>{!vertical&&<CheckCircle2 size={16}/>}</button></div>
                <label className="toggle-row"><span className="toggle-icon"><Captions size={17}/></span><span className="toggle-copy"><b>Burn in captions</b><small>Add readable text over your exported video</small></span><input type="checkbox" checked={captions} onChange={e=>setCaptions(e.target.checked)}/><span className="toggle-ui"/></label>
                {captions&&<input className="caption-input" value={captionText} onChange={e=>setCaptionText(e.target.value)} maxLength={120} placeholder="Type a short caption to burn into the video"/>}
                <button className="export-btn" onClick={exportClip} disabled={exporting}>{exporting?<><LoaderCircle className="spin" size={18}/> Rendering MP4...</>:<><Download size={18}/> Export MP4 <span>↗</span></>}</button>
                {exported&&<div className="success-box"><CheckCircle2 size={17}/><div><b>Your clip is ready</b><small>{exported.duration}s · MP4 · {exported.vertical?'9:16':'16:9'}</small>{exported.warning&&<small>{exported.warning}</small>}<a href={exported.url} download={exported.filename}><Download size={14}/> Download video</a></div></div>}
              </div>
            </div>
          </div>
        </section>}
        <section className="how-section"><div className="how-title"><span className="eyebrow">SIMPLE WORKFLOW</span><h2>From full-length to feed-ready</h2></div><div className="how-grid"><div className="how-card"><span>01</span><Link2 size={20}/><b>Add a video</b><p>Paste a supported link or upload a video file.</p></div><div className="how-card"><span>02</span><Sparkles size={20}/><b>Find moments</b><p>Get candidate time ranges based on available transcript analysis.</p></div><div className="how-card"><span>03</span><Download size={20}/><b>Export your clip</b><p>Choose aspect ratio, add a caption, and render an MP4.</p></div></div></section>
        <footer><div className="brand small-brand"><div className="brand-icon"><Scissors size={16}/></div><span>ViralClip<span className="brand-ai"> AI</span></span></div><span>Open-source starter · Self-hosted · Use content responsibly</span><a href="https://github.com/" target="_blank" rel="noreferrer">GitHub <ExternalLink size={12}/></a></footer>
      </div>
    </main>
  </div>
}
createRoot(document.getElementById('root')).render(<App/>);
