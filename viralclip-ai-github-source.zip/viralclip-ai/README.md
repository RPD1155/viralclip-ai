# ViralClip AI (open-source starter)

A self-hostable web app for finding candidate 15–30 second clips from videos you own or are authorized to edit.

## What works
- Responsive React UI with URL input, upload, clip cards, preview player, caption toggle, 9:16/16:9 output choice, and MP4 download.
- FastAPI backend accepts an uploaded video or a supported URL.
- FFmpeg creates MP4 clips and applies a vertical center crop for 9:16.
- Optional Whisper transcription; transcript segments are used to suggest candidate moments and can be burned in as time-synced subtitles.
- If Whisper is not installed / model is unavailable, the API returns sensible evenly spaced candidate clips and clearly marks them as heuristic rather than AI-ranked.

## Important limitations
- “Viral” is not guaranteed. Suggestions are candidate moments, not predictions of performance.
- URL importing depends on the source, network, access permissions, and that site's terms. Use only videos you own or have permission to process. The app does not bypass DRM, paywalls, login walls, or access controls.
- This starter runs processing on the same machine as the backend. Long videos can consume significant CPU, disk, and RAM. For production, add a job queue, quotas, authentication, cleanup policies, and object storage.
- Whisper is optional and downloads model weights on first use. The `base` model is a practical starting point; `tiny` is faster.
- Burned-in captions need FFmpeg's `libass` support. If unavailable, the app still exports the video, but captions may be omitted with a warning.

## Requirements
- Python 3.10+
- Node.js 18+
- FFmpeg and ffprobe installed and available on PATH
- For URL import: `yt-dlp` installed in the backend virtual environment
- Optional transcription: install `openai-whisper` (PyTorch dependency)

## Run locally

### 1) Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Install FFmpeg separately:
- Windows: install a trusted FFmpeg build and add its `bin` folder to PATH.
- macOS: `brew install ffmpeg`
- Debian/Ubuntu: `sudo apt install ffmpeg`

Optional transcription:
```bash
pip install openai-whisper
```
Set `ENABLE_WHISPER=true` in `.env`. On first transcription, Whisper downloads its selected model.

### 2) Frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Vite prints the local URL (usually `http://localhost:5173`).

The Vite development server proxies `/api` to `http://127.0.0.1:8000`.

## Deploying
- Frontend: any static host (Cloudflare Pages, Netlify, GitHub Pages with configuration, etc.).
- Backend: a Python host/container that allows FFmpeg and sufficient CPU/disk. A static GitHub Pages site alone cannot run video processing.
- Set `VITE_API_BASE_URL` if frontend and backend are deployed separately.
- Configure CORS in `backend/.env` for your frontend origin.
- Keep generated media private and add automatic file cleanup before public deployment.

## GitHub
Create a new repository, then:
```bash
git init
git add .
git commit -m "Initial ViralClip AI source"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/viralclip-ai.git
git push -u origin main
```

## API
- `GET /api/health`
- `POST /api/analyze` JSON `{ "url": "...", "duration": 20 }`
- `POST /api/upload` multipart `file`, optional `duration`
- `POST /api/export` JSON `{ "job_id": "...", "start": 12.5, "duration": 20, "vertical": true, "captions": true }`
- `GET /media/{filename}` serves generated preview/download files

For URL import, `yt-dlp` must be installed. If the URL cannot be accessed lawfully or technically, upload a local video file instead.
